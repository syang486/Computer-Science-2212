package baseEntities;


 
 /**
  * @author Shulan Yang
  *  
  * Base Interface for Publisher and Subscriber classes
  */
public interface IEntity {

}
